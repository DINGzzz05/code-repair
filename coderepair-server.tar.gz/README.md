# CodeRepairRL

将编码 Agent 嵌入强化学习训练循环（agent-in-the-loop RL），使用 GRPO/GSPO 训练
LLM 在真实仓库中完成多步代码修复：导航、定位、编辑，并以生成 patch 与 golden
patch 的相似度作为稀疏奖励。

## 核心内容

- **训练数据**：SWE-Gym（约 2.4k 任务），MD5 确定性切分训练/评测，防止数据泄漏
- **评测**：SWE-Bench-Verified 主测；Defects4J / GitBug-Java 跨语言泛化；
  BugsInPy / QuixBugs sanity check
- **基建**：深度定制 TRL fork（`rollout_func` 替换 `model.generate()`）+
  自研 vLLM OpenAI 兼容异步推理服务（多 Agent 并发 rollout + prefix caching）
- **训练**：SFT → GRPO/GSPO 两阶段；LoRA + DeepSpeed ZeRO-2；BF16；
  Tool Response Masking（工具输出不参与 loss/KL/裁剪统计）
- **数据管线**：难度测量分桶、难度退火课程、live difficulty 在线重分桶、
  harness 实测回填、高 pass-rate 轨迹限流、Gold Divergence 污染检测

## 环境配置（Ubuntu + conda）

```bash
# 一键创建 /data/dzz/envs/coderepair 并安装全部依赖
bash scripts/setup_coderepair_env.sh /data/dzz/coderepair

# 日常激活
conda activate /data/dzz/envs/coderepair
```

要求：conda、NVIDIA 驱动（脚本按驱动版本自动选择 CUDA 12.8 / 12.6 的 torch）、
磁盘剩余 ≥ 25 GB。首次运行会编译 flash-attn（约 10-30 分钟）。

## 目录结构

```text
src/                # 训练、奖励、数据、Agent 封装
  train_sft.py      # SFT 训练入口
  train_grpo.py     # GRPO/GSPO 训练入口
  rewards/          # 奖励函数（diff 相似度、终端调试习惯、格式等）
  trainers/         # 课程训练器等 Trainer 扩展
  data/             # 数据集加载（SWE-Gym / Stack / PrimeVul）
  agents/           # nano（轻量）/ mini（重量）Agent rollout
  live_difficulty.py# 在线难度校准
  harness_worker.py # 异步 SWE-bench harness 回填
scripts/            # 训练/评测脚本（4090 单机、集群）
benchmarks/         # SWE-bench 评测配置与流水线
tests/              # 奖励函数 / mask / 数据管线单元测试
```

## 快速开始

- 4×RTX 4090 单机：`scripts/4090/01_sft_8b.sh` → `02_vllm_serve.sh` →
  `03_grpo_8b.sh`
- 集群（SLURM）：`scripts/grpo/`、`scripts/sft/`
- 评测：`benchmarks/swe_bench/`

## 说明

- 详细设计、实验计划与进度记录见 `docs/`（本仓库本地维护，未纳入版本管理）。
- 当前实验进度：SFT/GRPO 数据管线与 14B 端到端 RL 已跑通，SWE-Bench-Verified
  评测与消融实验进行中。
